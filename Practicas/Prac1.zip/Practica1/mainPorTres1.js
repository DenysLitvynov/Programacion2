//
// Función que recibe un número y devuelve el resultado de multiplicarlo por 3
// R -> porTres() -> R
//
function porTres(num){
    return num*3;
}//()

//--------------------------------------------
// main()
//--------------------------------------------

// prueba automática
if(porTres(3)!=9){
    console.log("Esta mal");
}//()

//----------------------------------------
//----------------------------------------
//----------------------------------------