//
// Archivo: bib.js
// Descripción: contiene dos funciones que van a ser utilizadas desde main.js.
// Fecha: 15/04/2024
// Nombre: Denys Litvynov
//

// ––––––––––––––-
// R -> porDos() -> R
// ––––––––––––––-
module.exports.porDos = function ( a ) {
    return a * 2
} // ()

// ––––––––––––––-
// R -> porTres() -> R
// ––––––––––––––-
module.exports.porTres = function ( a ) {
    return a * 3
} // ()

//--------------------------------------------
//--------------------------------------------
//--------------------------------------------